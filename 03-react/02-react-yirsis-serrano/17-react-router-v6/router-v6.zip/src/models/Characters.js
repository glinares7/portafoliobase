export const Characters = [
  {
    id: "bardock",
    name: "Bardock",
    description: "Papá de Goku",
    type: "h",
  },
  {
    id: "gohan",
    name: "Gohan",
    description: "Hijo mayor de Goku",
    type: "h",
  },
  {
    id: "goku",
    name: "Goku",
    description: "Protagonista de DB",
    type: "h",
  },
  {
    id: "krillin",
    name: "Krillin",
    description: "Mejor amigo de Goku",
    type: "h",
  },
  {
    id: "majin_buu",
    name: "Majin Buu",
    description: "Enemigo en la saga de Buu en DB Z",
    type: "h",
  },

  {
    id: "piccolo",
    name: "Piccolo",
    description: "Enemigo y despues amigo de Goku",
    type: "h",
  },
  {
    id: "vegeta",
    name: "Vegeta",
    description: "Principe de los Saiyajin",
    type: "h",
  },
  {
    id: "bulma",
    name: "Bulma",
    description: "Esposa de Vegeta",
    type: "m",
  },
  {
    id: "caulifla",
    name: "Caulifla",
    description: "Saiyajin de otro universo",
    type: "m",
  },
  {
    id: "gine",
    name: "Gine",
    description: "Mamá de Goku",
    type: "m",
  },
  {
    id: "milk",
    name: "Milk",
    description: "Esposa de Goku",
    type: "m",
  },
  {
    id: "no18",
    name: "Androide No. 18",
    description: "Esposa de Krillin",
    type: "m",
  },
  {
    id: "vados",
    name: "Vados",
    description: "Angel del dios de la destruccion Champa",
    type: "m",
  },
  {
    id: "videl",
    name: "Videl",
    description: "Esposa de Gohan",
    type: "m",
  },
];
