export const types = {
  login: "[Auth] login",
  logout: "[Auth] logout",

  nominaAdd: "[Nomina] add",
  nominaDelete: "[Nomina] delete",
  nominaRead: "[Nomina] read",
  nominaClean: "[Nomina] clean",
};
